const API_URL = 'https://overtime-ddyl.onrender.com/api/partidos';

export async function fetchPartidos(token) {
  const res = await fetch(API_URL, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error('Error al cargar partidos');
  return await res.json();
}

export async function fetchPartidoById(id, token) {
  const res = await fetch(`${API_URL}/${id}`, {
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  });
  if (!res.ok) throw new Error('Error al cargar partido');
  return await res.json();
}

export async function agregarPartido(partido, token) {
  const res = await fetch(API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(partido),
  });
  if (!res.ok) {
    const errorData = await res.json();
    throw new Error(errorData.message || 'Error al agregar partido');
  }
  return await res.json();
}

export async function editarPartido(id, partido, token) {
  const res = await fetch(`${API_URL}/${id}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(partido),
  });
  if (!res.ok) {
    const errorData = await res.json();
    throw new Error(errorData.message || 'Error al editar partido');
  }
  return await res.json();
}

export async function eliminarPartido(id, token) {
  const res = await fetch(`${API_URL}/${id}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) {
    const errorData = await res.json();
    throw new Error(errorData.message || 'Error al eliminar partido');
  }
  return true;
}

// Para sets

export async function agregarSet(partidoId, numeroSet, token) {
  const res = await fetch(`${API_URL}/${partidoId}/sets`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ numeroSet }),
  });

  if (!res.ok) {
    const text = await res.text();
    console.error('Error al agregar set - respuesta cruda:', text);
    let errorMsg = 'Error al agregar set';

    try {
      const errorData = JSON.parse(text);
      errorMsg = errorData.error || errorData.message || errorMsg;
    } catch {
      errorMsg = text; // Si no es JSON, mostramos el texto literal (probablemente HTML)
    }

    throw new Error(errorMsg);
  }

  return await res.json();
}

export async function guardarEstadisticasSet(partidoId, numeroSet, statsJugadoresSet, token) {
  const res = await fetch(`${API_URL}/${partidoId}/sets/${numeroSet}/stats`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ statsJugadoresSet }),
  });
  if (!res.ok) {
    const errorData = await res.json();
    throw new Error(errorData.error || 'Error al guardar estadísticas');
  }
  return await res.json();
}
