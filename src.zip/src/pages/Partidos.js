import React, { useState, useEffect } from 'react';
import TarjetaPartido from '../components/modals/ModalPartido/tarjetapartido';
import ModalPartido from '../components/modals/ModalPartido/Modalpartido';
import PhysicsBall from '../components/common/LoadingGame/PhysicsBall';
import usePartidos from '../hooks/usePartidos';
import { useModal } from '../hooks/useModal';
import { getAuth, onAuthStateChanged, getIdToken } from 'firebase/auth';

export default function Partidos() {
  const [orden, setOrden] = useState('fecha_desc');
  const [partidoSeleccionado, setPartidoSeleccionado] = useState(null);
  const { isOpen, open, close } = useModal();
  const [token, setToken] = useState('');
  const [partidosOrdenados, setPartidosOrdenados] = useState([]);
  const { partidos, loading, error, setPartidos } = usePartidos(token);

  // Obtener token de Firebase Auth para usar en fetch
  useEffect(() => {
    const auth = getAuth();
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        const idToken = await getIdToken(user);
        setToken(idToken);
      } else {
        setToken('');
      }
    });
    return unsubscribe;
  }, []);

  // Ordenar partidos cuando cambie orden o partidos
  useEffect(() => {
    const ordenarPartidos = (list, criterio) => {
      const copia = [...list];
      switch (criterio) {
        case 'fecha_asc':
          return copia.sort((a, b) => new Date(a.fecha) - new Date(b.fecha));
        case 'fecha_desc':
          return copia.sort((a, b) => new Date(b.fecha) - new Date(a.fecha));
        case 'equipoLocal_asc':
          return copia.sort((a, b) => a.equipoLocal.nombre.localeCompare(b.equipoLocal.nombre));
        case 'equipoVisitante_asc':
          return copia.sort((a, b) => a.equipoVisitante.nombre.localeCompare(b.equipoVisitante.nombre));
        case 'aleatorio':
          return copia.sort(() => Math.random() - 0.5);
        default:
          return copia;
      }
    };

    setPartidosOrdenados((prev) => ordenarPartidos(prev, orden));
  }, [orden, setPartidos]);

  const handleOrdenChange = (e) => setOrden(e.target.value);

  const handleOpenModal = (partido) => {
    setPartidoSeleccionado(partido);
    open();
  };

  const handleCloseModal = () => {
    setPartidoSeleccionado(null);
    close();
  };

  if (loading) return <PhysicsBall />;
  if (error) return <div className="error-message">Error: {error}</div>;

  return (
    <div>
      <div style={styles.selector}>
        <label htmlFor="orden">Ordenar por: </label>
        <select id="orden" value={orden} onChange={handleOrdenChange}>
          <option value="fecha_desc">Fecha (más reciente)</option>
          <option value="fecha_asc">Fecha (más antigua)</option>
          <option value="equipoLocal_asc">Equipo Local (A-Z)</option>
          <option value="equipoVisitante_asc">Equipo Visitante (A-Z)</option>
          <option value="aleatorio">Orden aleatorio</option>
        </select>
      </div>

      <div style={styles.lista}>
        {partidos.map((partido) => (
          <TarjetaPartido
            key={partido._id}
            partido={partido}
            onClick={() => handleOpenModal(partido)}
          />
        ))}
      </div>

      {isOpen && partidoSeleccionado && (
        <ModalPartido partido={partidoSeleccionado} onClose={handleCloseModal} />
      )}
    </div>
  );
}

const styles = {
  selector: {
    textAlign: 'center',
    margin: '1rem 0',
  },
  lista: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: '10px',
    padding: '10px',
  },
};
