// src/pages/LandingPage.js
import React from 'react';
import { useNavigate } from 'react-router-dom';
//import './LandingPage.css'; // Opcional si querés estilo personalizado

const LandingPage = () => {
  const navigate = useNavigate();

  return (
    <div className="container">
      <h1>Bienvenido a OVERTIME</h1>
      <p>La forma más fácil de anotar y seguir tus partidos de dodgeball.</p>
      <div className="landing-buttons">
        <button onClick={() => navigate('/registro')}>Registrarse</button>
        <button onClick={() => navigate('/login')}>Iniciar sesión</button>
      </div>
    </div>
  );
};

export default LandingPage;
