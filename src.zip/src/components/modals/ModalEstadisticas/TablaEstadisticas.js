import React from 'react'

export default function TablaEstadisticas({ jugadores, estadisticas, onChange }) {
  return (
    <table className="tabla-estadisticas">
      <thead>
        <tr>
          <th>Jugador</th>
          <th>Lanzamientos</th>
          <th>Hits</th>
          <th>Outs</th>
          <th>Capturas</th>
        </tr>
      </thead>
      <tbody>
        {jugadores.map(j => (
          <tr key={j._id}>
            <td>{j.nombre} {j.apellido}</td>
            {['lanzamientos', 'hits', 'outs', 'capturas'].map(campo => (
              <td key={campo}>
                <input
                  type="number"
                  min="0"
                  value={estadisticas[j._id]?.[campo] || 0}
                  onChange={(e) => onChange(j._id, campo, e.target.value)}
                />
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  )
}
