import React from 'react';

export default function FormularioJugadorEstadisticas({ jugador, estadisticas, onChange }) {
  const handleChange = (campo, valor) => {
    onChange(jugador._id, campo, valor);
  };

  return (
    <div
      style={{
        border: '1px solid #ccc',
        borderRadius: 8,
        padding: '1rem',
        minWidth: 220,
        flex: '1 1 220px',
        marginBottom: '1rem',
      }}
    >
      <strong>{jugador.apodo || jugador.nombre}</strong>

      <div style={{ marginTop: 8 }}>
        <label>
          Lanzamientos:{' '}
          <input
            type="number"
            min={0}
            value={estadisticas.lanzamientos || 0}
            onChange={e => handleChange('lanzamientos', e.target.value)}
            style={{ width: 60 }}
          />
        </label>
      </div>

      <div>
        <label>
          Hits:{' '}
          <input
            type="number"
            min={0}
            value={estadisticas.hits || 0}
            onChange={e => handleChange('hits', e.target.value)}
            style={{ width: 60 }}
          />
        </label>
      </div>

      <div>
        <label>
          Outs:{' '}
          <input
            type="number"
            min={0}
            value={estadisticas.outs || 0}
            onChange={e => handleChange('outs', e.target.value)}
            style={{ width: 60 }}
          />
        </label>
      </div>

      <div>
        <label>
          Capturas:{' '}
          <input
            type="number"
            min={0}
            value={estadisticas.capturas || 0}
            onChange={e => handleChange('capturas', e.target.value)}
            style={{ width: 60 }}
          />
        </label>
      </div>
    </div>
  );
}
