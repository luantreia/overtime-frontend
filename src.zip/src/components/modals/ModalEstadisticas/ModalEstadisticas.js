import React, { useState } from 'react'
import SelectorJugadores from './SelectorJugadores'
import TablaEstadisticas from './TablaEstadisticas'
import FormularioJugadorEstadisticas from './FormularioJugadorEstadisticas';

import './ModalEstadisticas.css'

export default function ModalEstadisticas({ partido, onClose, onGuardarSet }) {
  const [setActivo, setSetActivo] = useState(null)
  const [jugadoresLocal, setJugadoresLocal] = useState([])
  const [jugadoresVisitante, setJugadoresVisitante] = useState([])
  const [estadisticas, setEstadisticas] = useState({}) // { jugadorId: { lanzamientos, hits, outs, capturas } }

  const iniciarNuevoSet = () => {
    setSetActivo({ numero: (partido.sets?.length || 0) + 1 })
    setJugadoresLocal([])
    setJugadoresVisitante([])
    setEstadisticas({})
  }

  const handleSeleccionJugadores = (equipo, seleccionados) => {
    equipo === 'local' ? setJugadoresLocal(seleccionados) : setJugadoresVisitante(seleccionados)
    seleccionados.forEach(j =>
      setEstadisticas(prev => ({
        ...prev,
        [j._id]: prev[j._id] || { lanzamientos: 0, hits: 0, outs: 0, capturas: 0 }
      }))
    )
  }

  const actualizarEstadistica = (jugadorId, campo, valor) => {
    setEstadisticas(prev => ({
      ...prev,
      [jugadorId]: {
        ...prev[jugadorId],
        [campo]: Math.max(0, Number(valor) || 0),
      }
    }))
  }

  const guardarSet = () => {
    if (jugadoresLocal.length !== 6 || jugadoresVisitante.length !== 6) {
      alert('Seleccioná 6 jugadores por equipo')
      return
    }

    const jugadoresSet = [...jugadoresLocal, ...jugadoresVisitante].map(j => ({
      jugador: j._id,
      equipo: j.equipoId,
      ...estadisticas[j._id],
    }))

    onGuardarSet(setActivo.numero, jugadoresSet)
    setSetActivo(null)
  }

  return (
    <div className="estadisticas-modal-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="estadisticas-modal">
        <button className="close-btn" onClick={onClose}>×</button>
        
        <h2>Estadísticas del Partido</h2>
        <p><strong>{partido.equipoLocal.nombre}</strong> vs <strong>{partido.equipoVisitante.nombre}</strong></p>
        <p>Categoría: {partido.categoria} · Modalidad: {partido.modalidad}</p>
        <p>Fecha: {new Date(partido.fecha).toLocaleString()}</p>
        
        {!setActivo && (
          <button className="add-set-btn" onClick={iniciarNuevoSet}>+ Agregar Set</button>
        )}

        {setActivo && (
          <>
            <h3>Set {setActivo.numero}</h3>
            <div className="selectors-row">
              <SelectorJugadores
                equipo="local"
                equipoNombre={partido.equipoLocal.nombre}
                equipoId={partido.equipoLocal._id}
                seleccionados={jugadoresLocal}
                onSeleccionar={handleSeleccionJugadores}
              />
              <SelectorJugadores
                equipo="visitante"
                equipoNombre={partido.equipoVisitante.nombre}
                equipoId={partido.equipoVisitante._id}
                seleccionados={jugadoresVisitante}
                onSeleccionar={handleSeleccionJugadores}
              />
            </div>

            {(jugadoresLocal.length === 6 && jugadoresVisitante.length === 6) && (
                <>
                    <h3>Estadísticas por jugador</h3>

                    <div style={{ display: 'flex', gap: '2rem', flexWrap: 'wrap' }}>
                    {[...jugadoresLocal, ...jugadoresVisitante].map(jugador => (
                        <FormularioJugadorEstadisticas
                        key={jugador._id}
                        jugador={jugador}
                        estadisticas={estadisticas[jugador._id] || {}}
                        onChange={actualizarEstadistica}
                        />
                    ))}
                    </div>

                    <button className="guardar-btn" onClick={guardarSet} style={{ marginTop: '1.5rem' }}>
                    Guardar Set
                    </button>
                </>
                )}
          </>
        )}
      </div>
    </div>
  )
}
