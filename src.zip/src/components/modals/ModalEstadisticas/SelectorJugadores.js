import React, { useEffect, useState } from 'react';

export default function SelectorJugadores({ equipo, equipoNombre, equipoId, seleccionados, onSeleccionar }) {
  const [jugadores, setJugadores] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!equipoId) return;

    const controller = new AbortController();
    setLoading(true);

    fetch(`https://overtime-ddyl.onrender.com/api/jugadores?equipoId=${equipoId}`, {
      signal: controller.signal,
    })
      .then(res => {
        if (!res.ok) throw new Error('Error al cargar jugadores');
        return res.json();
      })
      .then(data => {
        setJugadores(data);
        setLoading(false);
      })
      .catch(err => {
        if (err.name === 'AbortError') return;
        console.error(err);
        setJugadores([]);
        setLoading(false);
      });

    return () => controller.abort();
  }, [equipoId]);

  // seleccionados es un array con hasta 6 jugadores (pueden ser null o undefined si no hay)
  // Actualizamos un jugador en la posición index
  const handleChange = (index, e) => {
    const jugadorId = e.target.value;
    let nuevoSeleccionados = [...seleccionados];

    if (jugadorId === '') {
      nuevoSeleccionados[index] = null;
    } else {
      const jugadorSeleccionado = jugadores.find(j => j._id === jugadorId);
      nuevoSeleccionados[index] = jugadorSeleccionado || null;
    }

    // Quitamos duplicados si el usuario elige un jugador ya seleccionado en otro select
    // Por ejemplo, si eligió un jugador que ya estaba en otro slot, lo removemos del otro slot
    const seenIds = new Set();
    nuevoSeleccionados = nuevoSeleccionados.map(j => {
      if (j && seenIds.has(j._id)) return null;
      if (j) seenIds.add(j._id);
      return j;
    });

    onSeleccionar(equipo, nuevoSeleccionados);
  };

  // Obtener IDs ya seleccionados para evitar que se repitan
  const idsSeleccionados = seleccionados.filter(Boolean).map(j => j._id);

  return (
    <div style={{ flex: 1, minWidth: 260 }}>
      <label style={{ display: 'block', fontWeight: 'bold', marginBottom: 8 }}>
        {equipoNombre}
      </label>

      {loading ? (
        <p>Cargando jugadores...</p>
      ) : (
        <>
          {[...Array(6)].map((_, idx) => (
            <div key={idx} style={{ marginBottom: 10 }}>
              <select
                value={seleccionados[idx]?._id || ''}
                onChange={e => handleChange(idx, e)}
                style={{ width: '100%', padding: '5px', fontSize: '1rem' }}
              >
                <option value="">-- Elegí jugador {idx + 1} --</option>
                {jugadores.map(j => {
                  // Permitimos seleccionar el jugador si no está seleccionado en otro slot o si ya está seleccionado en este slot
                  const estaSeleccionadoEnOtro = idsSeleccionados.includes(j._id) && (seleccionados[idx]?._id !== j._id);
                  return (
                    <option
                      key={j._id}
                      value={j._id}
                      disabled={estaSeleccionadoEnOtro}
                    >
                      {j.apodo || j.nombre}
                    </option>
                  );
                })}
              </select>
            </div>
          ))}
          <small>Seleccioná 6 jugadores, uno por cada slot</small>
        </>
      )}
    </div>
  );
}
