// src/components/modals/ModalPartido/ModalPartido.js
import React, { useState } from 'react';
//import RegistrarEstadisticasPartido from './Stats/RegistrarEstadisticas';
import ModalEstadisticas from '../ModalEstadisticas/ModalEstadisticas';
import { useNavigate } from 'react-router-dom';

export default function ModalPartido({ partido, onClose }) {
  const [statsOpen, setStatsOpen] = useState(false);

  if (!partido) return null;

  const formattedDate = new Date(partido.fecha).toLocaleDateString('es-ES', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  const formattedTime = new Date(partido.fecha).toLocaleTimeString('es-ES', {
    hour: '2-digit',
    minute: '2-digit',
  });

  const renderJugadores = (jugadores) => {
    if (!jugadores || !Array.isArray(jugadores) || jugadores.length === 0) {
      return <p>No hay jugadores registrados.</p>;
    }
    return (
      <ul style={styles.list}>
        {jugadores.map((j, i) => (
          <li key={i}>
            {j.nombre} {j.apellido || ''} {j.numero ? ` (N°${j.numero})` : ''}
          </li>
        ))}
      </ul>
    );
  };

  const onOverlayClick = (e) => {
    if (e.target === e.currentTarget) onClose();
  };

  return (
    <>
      {/* Detalles del partido */}
      <div style={styles.overlay} onClick={onOverlayClick}>
        <div style={styles.modal}>
          <button onClick={onClose} style={styles.closeButton}>×</button>
          <h2 style={styles.title}>Detalles del Partido</h2>
          <div style={styles.content}>
            <p><strong>Liga:</strong> {partido.liga || 'N/A'}</p>
            <p><strong>Categoría:</strong> {partido.categoria || 'N/A'}</p>
            <p><strong>Modalidad:</strong> {partido.modalidad || 'N/A'}</p>
            <p><strong>Fecha:</strong> {formattedDate} {formattedTime}</p>
            <p><strong>Local:</strong> {partido.equipoLocal?.nombre || 'N/A'}</p>
            <p><strong>Visitante:</strong> {partido.equipoVisitante?.nombre || 'N/A'}</p>
            <p><strong>Marcador:</strong> {partido.marcadorLocal ?? '-'} – {partido.marcadorVisitante ?? '-'}</p>

            <h3>Jugadores Local</h3>
            {renderJugadores(partido.jugadoresLocal)}

            <h3>Jugadores Visitante</h3>
            {renderJugadores(partido.jugadoresVisitante)}

            <button
              style={styles.actionButton}
              onClick={() => setStatsOpen(true)}
            >
              Registrar Estadísticas
            </button>
          </div>
        </div>
      </div>

      {/* Modal full‑screen de estadísticas */}
      {statsOpen && (
        <div style={styles.fullOverlay} onClick={(e) => {
          if (e.target === e.currentTarget) setStatsOpen(false);
        }}>
          <ModalEstadisticas
            partido={partido}
            onClose={() => setStatsOpen(false)}
            onGuardarSet={(numSet, jugadoresSet) => {
              // aquí guardás los datos en el backend o estado padre, o actualizás partido
              console.log('Guardar set', numSet, jugadoresSet);
              setStatsOpen(false);
            }}
          />
        </div>
      )}
    </>
  );
}

const styles = {
  overlay: {
    position: 'fixed',
    top: 0, left: 0, right: 0, bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.6)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  modal: {
    backgroundColor: '#fff',
    borderRadius: '8px',
    width: '90%',
    maxWidth: '600px',
    maxHeight: '80vh',
    overflowY: 'auto',
    padding: '20px',
    position: 'relative',
  },
  fullOverlay: {
    position: 'fixed',
    top: 0, left: 0, right: 0, bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.8)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1100, // por encima del primer modal
  },
  fullModal: {
    backgroundColor: '#fff',
    borderRadius: 0,
    width: '100%',
    height: '100%',
    overflowY: 'auto',
    padding: '1.5rem',
    position: 'relative',
    boxSizing: 'border-box',
  },
  closeButton: {
    position: 'absolute',
    top: '1rem',
    right: '1rem',
    background: 'transparent',
    border: 'none',
    fontSize: '1.5rem',
    cursor: 'pointer',
    color: '#333',
  },
  title: {
    marginTop: 0,
    textAlign: 'center',
    color: '#222',
  },
  content: {
    lineHeight: '1.6',
    color: '#444',
  },
  list: {
    listStyle: 'none',
    padding: 0,
    margin: '0.5rem 0 1rem',
  },
  actionButton: {
    marginTop: '1rem',
    padding: '0.75rem 1.25rem',
    backgroundColor: '#28a745',
    color: '#fff',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    fontSize: '1rem',
  },
};
