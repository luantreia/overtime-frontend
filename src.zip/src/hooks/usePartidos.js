import { useState, useEffect } from 'react';
import {
  fetchPartidos,
  agregarPartido,
  editarPartido,
  eliminarPartido,
} from '../services/partidoService';

export default function usePartidos(token) {
  const [partidos, setPartidos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const cargarPartidos = async () => {
    try {
      setLoading(true);
      const data = await fetchPartidos(token);
      setPartidos(data);
    } catch (err) {
      setError(err.message || 'Error al cargar partidos');
    } finally {
      setLoading(false);
    }
  };

  const agregar = async (partido) => {
    try {
      const nuevo = await agregarPartido(partido, token);
      setPartidos((prev) => [...prev, nuevo]);
    } catch (err) {
      setError(err.message || 'Error al agregar partido');
      throw err; // para manejarlo desde el componente si se quiere
    }
  };

  const editar = async (id, partido) => {
    try {
      const actualizado = await editarPartido(id, partido, token);
      setPartidos((prev) =>
        prev.map((p) => (p._id === id ? actualizado : p))
      );
    } catch (err) {
      setError(err.message || 'Error al editar partido');
      throw err;
    }
  };

  const eliminar = async (id) => {
    try {
      await eliminarPartido(id, token);
      setPartidos((prev) => prev.filter((p) => p._id !== id));
    } catch (err) {
      setError(err.message || 'Error al eliminar partido');
      throw err;
    }
  };

  useEffect(() => {
    if (token) {
      cargarPartidos();
    } else {
      setPartidos([]);
    }
  }, [token]);

  return {
    partidos,
    setPartidos,
    loading,
    error,
    agregar,
    editar,
    eliminar,
  };
}
